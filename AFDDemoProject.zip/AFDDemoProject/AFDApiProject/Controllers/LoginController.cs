﻿using AFDApiProject.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AFDApiProject.Controllers
{
    public class LoginController : Controller
    {
        public string strConn = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;
        // GET: Login
        public ActionResult Index()
        {
            ViewBag.UserData = null;
            return View();
        }

        [HttpPost]
        public ActionResult Index(UserProfile model)
        {
            UserLoginResp resp = new UserLoginResp();
            try
            {
                using (SqlConnection connection = new SqlConnection(strConn))
                {
                    connection.Open();
                    string query = $"SELECT * FROM UserLogins WHERE username = '" + model.Email + "' AND password = '" + model.Password + "'";
                    SqlCommand command = new SqlCommand(query, connection);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            resp.LoginSuccess = true;
                            resp.FirstName = reader["FirstName"].ToString();
                            resp.LastName = reader["LastName"].ToString();
                            resp.Email = reader["UserName"].ToString();
                            resp.ErrorMsg = string.Empty;
                        }
                    }
                    connection.Close();
                }

                if (resp.LoginSuccess)
                {
                    Session["UserData"] = resp;
                    return RedirectToAction("Index", "Account");
                }
                else
                {
                    resp.LoginSuccess = false;
                    resp.ErrorMsg = "Invalid username or password";
                }
            }
            catch (Exception ex)
            {
                resp.LoginSuccess = false;
                resp.ErrorMsg = ex.Message.ToString();
            }

            TempData["UserData"] = resp;
            ViewBag.UserData = resp;

            return View();
        }

        public ActionResult Logout()
        {
            Session["UserData"] = null;
            Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}