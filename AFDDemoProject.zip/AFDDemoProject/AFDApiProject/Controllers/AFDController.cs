﻿using AFDApiProject.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using System.Web.Http.Results;

namespace AFDApiProject.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class AFDController : ApiController
    {
        public string strConn = ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString;

        [HttpGet]
        public UserData GetUser(string id)
        {
            UserData resp = new UserData();
            try
            {
                using (SqlConnection connection = new SqlConnection(strConn))
                {
                    connection.Open();
                    string query = $"SELECT * FROM UserLogins WHERE ID = " + id;
                    SqlCommand command = new SqlCommand(query, connection);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            resp.FirstName = reader["FirstName"].ToString();
                            resp.LastName = reader["LastName"].ToString();
                            resp.Email = reader["UserName"].ToString();
                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                resp.Email = ex.Message.ToString();
            }

            return resp;
        }

        [HttpPost]
        public UserLoginResp Login([FromBody] UserProfile model)
        {
            UserLoginResp resp = new UserLoginResp();
            try
            {
                using (SqlConnection connection = new SqlConnection(strConn))
                {
                    connection.Open();
                    string query = $"SELECT * FROM UserLogins WHERE username = '" + model.Email + "' AND password = '" + model.Password + "'";
                    SqlCommand command = new SqlCommand(query, connection);
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            resp.LoginSuccess = true;
                            resp.FirstName = reader["FirstName"].ToString();
                            resp.LastName = reader["LastName"].ToString();
                            resp.Email = reader["UserName"].ToString();
                            resp.ErrorMsg = string.Empty;
                        }
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                resp.LoginSuccess = false;
                resp.ErrorMsg = ex.Message.ToString();
            }

            return resp;
        }
    }
}
