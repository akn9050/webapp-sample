﻿using AFDApiProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AFDApiProject.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Index()
        {
            if (Session["UserData"] != null)
            {
                UserLoginResp resp = (UserLoginResp)Session["UserData"];
                ViewBag.UserData = resp;
                return View();
            }
            else
            {
                return RedirectToAction("Index", "Login");
            }
        }
    }
}