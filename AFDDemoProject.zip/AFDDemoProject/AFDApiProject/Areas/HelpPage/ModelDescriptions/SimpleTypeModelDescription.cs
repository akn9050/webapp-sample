namespace AFDApiProject.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}